#!/bin/bash

# 诊断Agent快速部署脚本 - Ingress版本
# 用于在K8s集群中部署诊断Agent并通过Ingress暴露

set -e

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 配置变量（请根据实际情况修改）
NAMESPACE="${NAMESPACE:-default}"
DOMAIN="${DOMAIN:-diagnostic-agent.yourdomain.com}"
IMAGE="${IMAGE:-diagnostic-agent:v1}"
TIMEOUT="${TIMEOUT:-300}"

echo -e "${GREEN}======================================${NC}"
echo -e "${GREEN}诊断Agent部署脚本 (Ingress版本)${NC}"
echo -e "${GREEN}======================================${NC}"
echo ""

# 显示配置信息
echo -e "${YELLOW}当前配置:${NC}"
echo "  命名空间: $NAMESPACE"
echo "  域名: $DOMAIN"
echo "  镜像: $IMAGE"
echo "  超时: ${TIMEOUT}秒"
echo ""

read -p "确认部署? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${RED}部署已取消${NC}"
    exit 1
fi

# 部署步骤...
echo -e "${YELLOW}开始部署...${NC}"

# 部署k8s-deployment.yaml
kubectl apply -f k8s-deployment.yaml

# 部署Ingress
envsubst < ingress.yaml | kubectl apply -f -

echo -e "${GREEN}✓ 部署完成${NC}"
