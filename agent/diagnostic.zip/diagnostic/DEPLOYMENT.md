# 诊断Agent部署指南

## 架构说明

```
本地OneOps后端 (localhost:8082)
    ↓ HTTP请求
Ingress (diagnostic-agent.yourdomain.com)
    ↓ 路由
K8s Service (diagnostic-service:8888)
    ↓ 负载均衡
DaemonSet Agent Pods (每个节点一个)
    ↓ Arthas诊断
Java应用Pod
```

## 部署步骤

### 第1步：构建并推送Agent镜像

```bash
cd /Users/mpm/Desktop/doc/go/OneOpsV2/OneOps/agent/diagnostic

# 方式1: 构建并推送到私有仓库
docker build -t your-registry/diagnostic-agent:v1 .
docker push your-registry/diagnostic-agent:v1

# 方式2: 如果使用阿里云容器镜像服务
docker build -t registry.cn-hangzhou.aliyuncs.com/your-namespace/diagnostic-agent:v1 .
docker push registry.cn-hangzhou.aliyuncs.com/your-namespace/diagnostic-agent:v1

# 方式3: 本地测试（加载到kind/minikube）
docker build -t diagnostic-agent:v1 .
# 如果使用kind
kind load docker-image diagnostic-agent:v1 --name your-cluster
# 如果使用minikube
eval $(minikube docker-env)
docker build -t diagnostic-agent:v1 .
```

### 第2步：修改部署配置

编辑 `k8s-deployment.yaml`，修改镜像地址：

```yaml
containers:
- name: diagnostic-agent
  image: your-registry/diagnostic-agent:v1  # 改为你的镜像地址
  imagePullPolicy: Always  # 如果使用远程仓库
```

### 第3步：部署到K8s集群

```bash
# 部署DaemonSet和Service
kubectl apply -f k8s-deployment.yaml

# 部署Ingress（先修改域名）
kubectl apply -f ingress.yaml

# 检查部署状态
kubectl get pods -n default -l app=diagnostic-agent
kubectl get svc -n default diagnostic-service
kubectl get ingress -n default diagnostic-agent-ingress

# 查看Agent日志
kubectl logs -n default -l app=diagnostic-agent -f
```

### 第4步：配置DNS解析

#### 方式1: 使用真实域名（推荐）

如果你的集群有Ingress Controller和域名：

```bash
# 获取Ingress Controller的外部IP
kubectl get svc -n ingress-nginx ingress-nginx-controller

# 配置DNS解析
# diagnostic-agent.yourdomain.com -> Ingress Controller IP
```

#### 方式2: 使用hosts文件（测试用）

```bash
# 获取Ingress Controller IP
INGRESS_IP=$(kubectl get svc -n ingress-nginx ingress-nginx-controller -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

# 添加到hosts文件
echo "$INGRESS_IP diagnostic-agent.yourdomain.com" | sudo tee -a /etc/hosts
```

#### 方式3: 使用NodePort（如果没有Ingress）

修改 `k8s-deployment.yaml` 中的Service：

```yaml
apiVersion: v1
kind: Service
metadata:
  name: diagnostic-service
  namespace: default
spec:
  type: NodePort  # 改为NodePort
  ports:
  - name: http
    port: 8888
    targetPort: 8888
    nodePort: 30088  # 可选，指定端口
  selector:
    app: diagnostic-agent
```

然后使用 `http://node-ip:30088/api/diagnostic` 访问

### 第5步：配置OneOps后端

编辑后端配置文件或设置环境变量：

#### 方式1: 环境变量（推荐）

```bash
# 在启动后端前设置环境变量
export DIAGNOSTIC_AGENT_URL="http://diagnostic-agent.yourdomain.com/api/diagnostic"

# 或者写入到启动脚本
cat > /Users/mpm/Desktop/doc/go/OneOpsV2/OneOps/backend/start.sh << 'EOF'
#!/bin/bash
export DIAGNOSTIC_AGENT_URL="http://diagnostic-agent.yourdomain.com/api/diagnostic"
go run main.go
EOF
chmod +x start.sh
./start.sh
```

#### 方式2: 修改代码中的默认值

编辑 `backend/controllers/diagnostic.go`：

```go
func (ctrl *DiagnosticController) getAgentURL() string {
	if url := os.Getenv("DIAGNOSTIC_AGENT_URL"); url != "" {
		return url
	}

	// 修改这里的默认值为你的Ingress域名
	return "http://diagnostic-agent.yourdomain.com/api/diagnostic"
}
```

### 第6步：验证部署

```bash
# 1. 测试Agent健康检查
curl http://diagnostic-agent.yourdomain.com/health

# 预期输出:
# {
#   "status": "healthy",
#   "version": "1.0.0",
#   "nodeName": "node-1",
#   "namespace": "default",
#   "podIP": "10.244.1.100",
#   "capabilities": ["thread", "heap", "jvm", "dashboard", "logger"]
# }

# 2. 测试诊断API
curl -X POST http://diagnostic-agent.yourdomain.com/api/diagnostic \
  -H "Content-Type: application/json" \
  -d '{
    "pod_name": "java-app-pod",
    "namespace": "default",
    "command": "jvm",
    "args": []
  }'

# 3. 从OneOps后端测试
# 登录OneOps，导航到K8s管理 -> 诊断中心
# 选择集群、命名空间、Pod
# 执行诊断命令
```

## 不同部署场景的配置

### 场景1: 生产环境（使用域名 + HTTPS）

```yaml
# ingress.yaml
spec:
  tls:
  - hosts:
    - diagnostic-agent.yourdomain.com
    secretName: diagnostic-agent-tls
  rules:
  - host: diagnostic-agent.yourdomain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: diagnostic-service
            port:
              number: 8888
```

```bash
# 后端配置
export DIAGNOSTIC_AGENT_URL="https://diagnostic-agent.yourdomain.com/api/diagnostic"
```

### 场景2: 测试环境（使用NodePort）

```yaml
# Service配置
spec:
  type: NodePort
  ports:
  - port: 8888
    targetPort: 8888
    nodePort: 30088
```

```bash
# 后端配置
export DIAGNOSTIC_AGENT_URL="http://k8s-node-ip:30088/api/diagnostic"
```

### 场景3: 开发环境（使用port-forward）

```bash
# 在本地建立port-forward
kubectl port-forward -n default svc/diagnostic-service 9100:8888 &

# 后端配置
export DIAGNOSTIC_AGENT_URL="http://localhost:9100/api/diagnostic"
```

## 安全配置建议

### 1. 启用基础认证

```bash
# 生成密码文件
htpasswd -c auth admin
# 输入密码: diagnostic123

# 创建Secret
kubectl create secret generic diagnostic-auth --from-file=auth -n default

# 在Ingress中启用认证
# 取消ingress.yaml中的认证注释
```

### 2. IP白名单

```yaml
# ingress.yaml
annotations:
  nginx.ingress.kubernetes.io/whitelist-source-range: "10.0.0.0/8,192.168.0.0/16,172.16.0.0/12"
```

### 3. 限流配置

```yaml
annotations:
  nginx.ingress.kubernetes.io/limit-rps: "10"
  nginx.ingress.kubernetes.io/limit-connections: "20"
```

## 故障排查

### Agent Pod无法启动

```bash
# 查看Pod状态
kubectl describe pod -n default -l app=diagnostic-agent

# 查看日志
kubectl logs -n default -l app=diagnostic-agent

# 常见问题:
# 1. 镜像拉取失败: 检查镜像地址和imagePullPolicy
# 2. RBAC权限不足: 检查ServiceAccount和RoleBinding
# 3. 资源不足: 调整resources.limits
```

### 无法访问Agent API

```bash
# 1. 检查Service
kubectl get svc -n default diagnostic-service
kubectl describe svc -n default diagnostic-service

# 2. 检查Ingress
kubectl describe ingress -n default diagnostic-agent-ingress

# 3. 检查Ingress Controller
kubectl get svc -n ingress-nginx

# 4. 测试Service连接
kubectl run -it --rm test --image=busybox -- wget -qO- http://diagnostic-service:8888/health

# 5. 测试Ingress连接
curl -H "Host: diagnostic-agent.yourdomain.com" http://ingress-ip/health
```

### 后端调用Agent失败

```bash
# 1. 检查环境变量
echo $DIAGNOSTIC_AGENT_URL

# 2. 手动测试连接
curl http://diagnostic-agent.yourdomain.com/health

# 3. 查看后端日志
tail -f /tmp/oneops_backend.log | grep "诊断Agent"

# 4. 检查网络连接
ping diagnostic-agent.yourdomain.com
telnet diagnostic-agent.yourdomain.com 80
```

## 监控和维护

### 查看Agent运行状态

```bash
# 查看所有Agent Pod
kubectl get pods -n default -l app=diagnostic-agent -o wide

# 查看资源使用
kubectl top pods -n default -l app=diagnostic-agent

# 查看最近的事件
kubectl get events -n default --field-selector involvedObject.kind=DaemonSet
```

### 更新Agent版本

```bash
# 构建新镜像
docker build -t your-registry/diagnostic-agent:v2 .
docker push your-registry/diagnostic-agent:v2

# 更新DaemonSet
kubectl set image daemonset/diagnostic-agent diagnostic-agent=your-registry/diagnostic-agent:v2 -n default

# 监控滚动更新
kubectl rollout status daemonset/diagnostic-agent -n default
```

### 清理资源

```bash
# 删除所有资源
kubectl delete -f ingress.yaml
kubectl delete -f k8s-deployment.yaml

# 或逐个删除
kubectl delete ingress diagnostic-agent-ingress -n default
kubectl delete svc diagnostic-service -n default
kubectl delete daemonset diagnostic-agent -n default
kubectl delete rolebinding diagnostic-agent -n default
kubectl delete role diagnostic-agent -n default
kubectl delete serviceaccount diagnostic-agent -n default
```

## 性能调优

### 调整并发连接数

```yaml
# 在Agent启动参数中添加
env:
- name: MAX_CONNECTIONS
  value: "100"
```

### 调整资源限制

```yaml
resources:
  requests:
    memory: "256Mi"
    cpu: "200m"
  limits:
    memory: "512Mi"
    cpu: "1000m"
```

### 优化超时设置

```yaml
annotations:
  nginx.ingress.kubernetes.io/proxy-read-timeout: "600"  # 10分钟
  nginx.ingress.kubernetes.io/proxy-send-timeout: "600"
  nginx.ingress.kubernetes.io/proxy-body-size: "100m"  # 允许更大的响应
```
