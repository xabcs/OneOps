# Java应用诊断识别说明

## 自动识别机制

诊断功能会自动识别K8s集群中的Java应用，识别规则如下：

### 1. 镜像名称识别（最常用）

如果容器镜像名称包含以下关键字，会被识别为Java应用：

```
✅ 基础镜像关键字：
- java, jdk, openjdk, oraclejdk

✅ 应用服务器：
- tomcat, jetty, jboss, wildfly

✅ 框架：
- spring, springboot

✅ 构建工具：
- gradle, maven

✅ 中间件：
- kafka, zookeeper, elasticsearch
- hadoop, spark, flink

✅ 镜像名称模式：
- jdk-*, java-*, openjdk-*
```

**示例：**
```yaml
# ✅ 会被识别
containers:
- name: app
  image: openjdk:11
- name: app
  image: tomcat:9
- name: app
  image: myregistry/spring-boot-app:v1
- name: app
  image: kafka:latest
```

### 2. 环境变量识别

如果容器有以下Java相关环境变量，会被识别：

```yaml
# ✅ 会被识别
env:
- name: JAVA_HOME
  value: /usr/lib/jvm/java-11
- name: JAVA_OPTS
  value: "-Xmx512m"
- name: JVM_OPTIONS
  value: "-XX:+UseG1GC"
- name: CATALINA_OPTS  # Tomcat专用
  value: "-Xms256m"
```

### 3. 启动命令识别

如果容器的Command或Args包含Java相关参数：

```yaml
# ✅ 会被识别
command: ["java", "-jar", "app.jar"]
args: ["-Xmx512m", "-Dspring.profiles.active=prod"]

# ✅ 会被识别
command: ["/bin/sh"]
args: ["-c", "java -jar /app/myapp.jar"]
```

### 4. 标签识别（推荐）

为Pod添加标签明确标识：

```yaml
metadata:
  labels:
    app-type: java          # ✅ 应用类型
    runtime: spring         # ✅ 运行时类型
    language: java          # ✅ 语言类型
```

### 5. 注解识别（推荐）

使用注解明确标记：

```yaml
metadata:
  annotations:
    diagnostic.oneops.io/java-app: "true"      # 明确标记为Java应用
    diagnostic.oneops.io/enabled: "true"       # 明确启用诊断
```

## 诊断可用性判断

Pod显示"可诊断"的条件（满足任一即可）：

### 方式1: Sidecar Agent（已部署Agent容器）

```yaml
containers:
- name: app
  image: myapp:v1
- name: diagnostic-agent  # ✅ 容器名包含"diagnostic"或"arthas"
  image: diagnostic-agent:v1
```

### 方式2: DaemonSet Agent（集群级Agent）

```yaml
# DaemonSet Agent已部署到集群
# 后端会检测Agent服务是否可访问
# 配置环境变量：
DIAGNOSTIC_AGENT_URL="http://diagnostic-agent.yourdomain.com/api/diagnostic"
```

### 方式3: 注解标记（显式启用）

```yaml
metadata:
  annotations:
    diagnostic.oneops.io/enabled: "true"  # ✅ 明确启用诊断
```

## 推荐配置

对于生产环境，建议使用**标签+注解**的方式明确标识：

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-java-app
  labels:
    app: my-service
    app-type: java
    runtime: springboot
  annotations:
    diagnostic.oneops.io/java-app: "true"
    diagnostic.oneops.io/enabled: "true"
spec:
  containers:
  - name: app
    image: myregistry/my-spring-app:v1.0.0
    env:
    - name: JAVA_OPTS
      value: "-Xms512m -Xmx1024m"
    resources:
      limits:
        memory: "1Gi"
        cpu: "500m"
```

## 排查指南

### Pod未显示在诊断列表

**检查步骤：**

1. **检查镜像名称**
   ```bash
   kubectl get pod <pod-name> -o jsonpath='{.spec.containers[*].image}'
   ```

2. **检查环境变量**
   ```bash
   kubectl get pod <pod-name> -o jsonpath='{.spec.containers[*].env[?(@.name=="JAVA_HOME")]}'
   ```

3. **检查启动命令**
   ```bash
   kubectl get pod <pod-name> -o yaml | grep -A 10 command
   ```

4. **添加标签或注解**（推荐）
   ```bash
   kubectl label pod <pod-name> app-type=java
   kubectl annotate pod <pod-name> diagnostic.oneops.io/java-app=true
   ```

### 显示"不可诊断"

**检查步骤：**

1. **确认Agent已部署**
   ```bash
   # 检查DaemonSet Agent
   kubectl get daemonset -A | grep diagnostic

   # 或检查Sidecar容器
   kubectl get pod <pod-name> -o jsonpath='{.spec.containers[*].name}'
   ```

2. **检查Agent服务**
   ```bash
   kubectl get svc -A | grep diagnostic
   kubectl get ingress -A | grep diagnostic
   ```

3. **配置后端Agent URL**
   ```bash
   export DIAGNOSTIC_AGENT_URL="http://your-agent-url/api/diagnostic"
   ```

## 常见问题

### Q: 自定义镜像名称（如`myapp:v1`）如何识别？

**A:** 添加标签或注解：
```yaml
labels:
  app-type: java
annotations:
  diagnostic.oneops.io/java-app: "true"
```

### Q: 多容器Pod如何识别？

**A:** 任一容器满足识别条件即可。建议主应用容器名称为`app`或`main`。

### Q: Init容器会被识别吗？

**A:** 不会。只检查`spec.containers`中的容器。

### Q: 如何强制启用诊断？

**A:** 使用注解：
```yaml
annotations:
  diagnostic.oneops.io/enabled: "true"
```
